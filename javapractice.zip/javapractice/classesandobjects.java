package javapractice;

public class classesandobjects
    {
int x=10;    
    }
