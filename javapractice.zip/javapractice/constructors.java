package javapractice;
public class constructors
    {
    public constructors()
        {
        System.out.println("This is a Class Constructor. It is automatically called when object is declared");
        }
    
    }
