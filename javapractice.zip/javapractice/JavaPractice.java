package javapractice;
import java.util.Scanner;
public class JavaPractice
    {
    public static void main(String[] args)
        {
        Scanner s = new Scanner(System.in);
        String name;
        name = s.nextLine();
        System.out.println("Entered Text : "+name);
        char[] arr= name.toCharArray();
        int l = arr[0]-'0';
        int m= arr[1]-'0';
        System.out.println(l);
        System.out.println(m);
        }
    }
