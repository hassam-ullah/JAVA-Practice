package javapractice;

abstract public class abstraction
    {
    public abstract void display();
    }
class C extends abstraction
    {
    public void display()
        {
            System.out.println("This is an Abstract function defined in child class");
        }
    }
