package javapractice;
import java.util.ArrayList;
public class arrayLists
    {
    ArrayList<String> al = new ArrayList(3);
    void setValue(String name)
        {
        al.add(name);
        }
    void display()
        {
        for(int i=0;i<3;i++)
            {
            System.out.println(al.get(i));
            }
        }
    
    }
