package javapractice;
public class attributes
    {
    String name="Hassam Ullah";
    int age=21;
    
    }
