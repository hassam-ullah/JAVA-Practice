package javapractice;
public class trycatch
    {
    public void trial()
        {
        try 
        {
        int[] ar={1,2,3,4,5};
        System.out.println(ar[10]);
        }
        catch(Exception e)
            {
            System.out.println("An error occured");
            }
        }
    
    }
