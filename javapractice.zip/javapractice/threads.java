package javapractice;
public class threads extends Thread
    {
    public void run()
        {
        System.out.println("This code is running in a Thread");
        }
    }

