package javapractice;

interface fun
    {
    public void fun1();
    public void fun2();
    public void fun3();
    }
public class interfaces implements fun
    {
    public void fun1()
        {
        System.out.println("This is Function 1 implemented from interface Fun");
        }
    public void fun2()
        {
        System.out.println("This is Function 2 implemented from interface Fun");
        }
    public void fun3()
        {
        System.out.println("This is Function 3 implemented from interface Fun");
        }
    }
