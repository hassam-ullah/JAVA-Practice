package javapractice;
class A
    {
    protected String name;
    protected int age;
    }
public class inheritence extends A
    {
    private String regno;
    public void setValues(String name, int age, String regno)
        {
        this.name=name;
        this.age=age;
        this.regno=regno;
        }
    public String getName(){
        return this.name; }
    public int getAge(){
        return this.age;
    }
    public String getRegno(){
        return this.regno;
    }
    }