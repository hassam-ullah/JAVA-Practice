package javapractice;
import java.util.LinkedList;
public class linkedLists
    {
    LinkedList<String> ll= new LinkedList<String>();
    void setValues(String name)
        {
        ll.add(name);
        }
    void display()
        {
        for(int i=0;i<ll.size();i++)
            {
            System.out.println(ll.get(i));
        }
    }
    }
