package javapractice;
public class methods
    {
public static void method()
    {
    System.out.println("This is a Method Being Called in Main");
    }
    }
