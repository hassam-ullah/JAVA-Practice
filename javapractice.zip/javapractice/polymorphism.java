package javapractice;
class B
    {
    public void func()
        {
        System.out.println("This function is defined in Parent Class");
        }
    }
public class polymorphism extends B
    {
    public polymorphism()
        {
        B b = new B();
        b.func();
        }
    @Override
    public void func()
        {
        System.out.println("This function is defined in Child Class");
        }
    }
